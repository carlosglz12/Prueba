<?php
session_destroy();
header("Location: ../vistas/login.php");
exit();
?>
